const $=s=>document.querySelector(s);
const store={g(k,d){try{const v=localStorage.getItem(k);return v===null?d:JSON.parse(v)}catch(e){return d}},s(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const SURAH=[
{n:"الفاتحة",a:["بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ","الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ","الرَّحْمَٰنِ الرَّحِيمِ","مَالِكِ يَوْمِ الدِّينِ","إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ","اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ","صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ"],
t:"سورة الفاتحة هي أم الكتاب؛ فيها حمد الله وتعظيمه، وإخلاص العبادة والاستعانة له وحده، وسؤاله الهداية إلى طريق الحق، وطريق من أنعم الله عليهم بالإيمان والعمل الصالح، بعيدًا عن طريق من عرفوا الحق وتركوه، ومن ضلوا عنه."},
{n:"آية الكرسي",a:["اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ"],
t:"أعظم آية في كتاب الله؛ تثبت أن الله وحده المستحق للعبادة، الحي الذي لا يموت، القائم على كل شيء، لا يغفل ولا ينام، وله الملك كله، ولا يشفع أحد عنده إلا بإذنه، وعلمه محيط بكل شيء، وسع كرسيه السماوات والأرض، وهو العلي في ذاته وقدره، العظيم في سلطانه."},
{n:"الإخلاص",a:["قُلْ هُوَ اللَّهُ أَحَدٌ","اللَّهُ الصَّمَدُ","لَمْ يَلِدْ وَلَمْ يُولَدْ","وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ"],
t:"تبيّن السورة توحيد الله: هو واحد لا شريك له، الصمد الذي تقصده الخلائق في حاجاتها، منزّه عن الولد والوالد، ولا مثيل له ولا نظير."},
{n:"الفلق",a:["قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ","مِنْ شَرِّ مَا خَلَقَ","وَمِنْ شَرِّ غَاسِقٍ إِذَا وَقَبَ","وَمِنْ شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ","وَمِنْ شَرِّ حَاسِدٍ إِذَا حَسَدَ"],
t:"استعاذة بالله، رب الصبح، من شر جميع المخلوقات، ومن شر الليل إذا اشتد ظلامه، ومن شر السحر، ومن شر الحاسد إذا أظهر حسده."},
{n:"الناس",a:["قُلْ أَعُوذُ بِرَبِّ النَّاسِ","مَلِكِ النَّاسِ","إِلَٰهِ النَّاسِ","مِنْ شَرِّ الْوَسْوَاسِ الْخَنَّاسِ","الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ","مِنَ الْجِنَّةِ وَالنَّاسِ"],
t:"استعاذة بالله، رب الناس وملكهم وإلههم، من شر الشيطان الذي يوسوس في الصدور ويختفي إذا ذُكر الله، سواء كان من الجن أو من الإنس."}];
const ADHKAR=DK;
const DUAA=[["رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ","البقرة ٢٠١"],["رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي","طه ٢٥–٢٦"],["رَبِّ زِدْنِي عِلْمًا","طه ١١٤"],["رَبَّنَا لَا تُؤَاخِذْنَا إِنْ نَسِينَا أَوْ أَخْطَأْنَا","البقرة ٢٨٦"],["حَسْبِيَ اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ","التوبة ١٢٩"],["رَبِّ اغْفِرْ لِي وَلِوَالِدَيَّ وَلِلْمُؤْمِنِينَ يَوْمَ يَقُومُ الْحِسَابُ","من آيات القرآن"]];
const HADITH=[["إِنَّمَا الْأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى","متفق عليه","الأعمال تُقبل وتُوزن بحسب النية والقصد."],["لَا يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لِأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ","متفق عليه","كمال الإيمان أن تحب الخير للآخرين كما تحبه لنفسك."],["مَنْ كَانَ يُؤْمِنُ بِاللَّهِ وَالْيَوْمِ الْآخِرِ فَلْيَقُلْ خَيْرًا أَوْ لِيَصْمُتْ","متفق عليه","حفظ اللسان من علامات الإيمان."],["الدِّينُ النَّصِيحَةُ","رواه مسلم","الدين قائم على الإخلاص والنصح لله ولكتابه ولرسوله ولأئمة المسلمين وعامتهم."],["الْكَلِمَةُ الطَّيِّبَةُ صَدَقَةٌ","متفق عليه","الكلام الطيب باب من أبواب الخير والأجر."]];
const CITIES={"صنعاء":[15.35,44.21,3],"عدن":[12.78,45.04,3],"تعز":[13.58,44.02,3],"إب":[13.97,44.18,3],"الحديدة":[14.8,42.95,3],"المكلا":[14.54,49.12,3],"مكة المكرمة":[21.42,39.83,3],"الرياض":[24.71,46.68,3],"القاهرة":[30.04,31.24,2]};
const PN=["الفجر","الظهر","العصر","المغرب","العشاء"];
const R=Math.PI/180,sin=x=>Math.sin(x*R),cos=x=>Math.cos(x*R),tan=x=>Math.tan(x*R),acos=x=>Math.acos(x)/R,asin=x=>Math.asin(x)/R;
const MET=[["أم القرى",18.5,0],["رابطة العالم الإسلامي",18,17],["الهيئة المصرية العامة للمساحة",19.5,17.5],["جامعة العلوم الإسلامية بكراتشي",18,18],["أمريكا الشمالية",15,15]];
function times(date,lat,lng,tz){const M=MET[pm]||MET[0];
 const d=Date.UTC(date.getFullYear(),date.getMonth(),date.getDate(),12)/864e5+2440587.5-2451545;
 const g=(357.529+.98560028*d)%360,q=(280.459+.98564736*d)%360,L=q+1.915*sin(g)+.02*sin(2*g),e=23.439-3.6e-7*d;
 let ra=Math.atan2(cos(e)*sin(L),cos(L))/R/15;ra=((ra%24)+24)%24;
 const D=asin(sin(e)*sin(L)),eq=q/15-ra;
 const noon=12+tz-lng/15-(((eq+12)%24+24)%24-12);
 const T=a=>acos((-sin(a)-sin(D)*sin(lat))/(cos(D)*cos(lat)))/15;
 const ac=Math.atan(1/(1+tan(Math.abs(lat-D))))/R;
 const asr=acos((sin(ac)-sin(D)*sin(lat))/(cos(D)*cos(lat)))/15;
 const mg=noon+T(.833);
 return [noon-T(M[1]),noon,noon+asr,mg,M[2]?noon+T(M[2]):mg+1.5];
}
let pcustom=store.g("pcustom",{});
const ptimes=(d,la,ln,tz)=>times(d,la,ln,tz).map((x,i)=>{const key=String(i),v=pcustom[key];if(v&&/^\\d{2}:\\d{2}$/.test(v)){const [h,m]=v.split(":").map(Number);return h+m/60}return x+(adj[i]||0)/60});
const fmt=h=>{h=((h%24)+24)%24;let m=Math.round(h*60),H=Math.floor(m/60)%24,M=m%60,p=H>=12?"م":"ص";H=H%12||12;return H+":"+String(M).padStart(2,"0")+" "+p};

let city=store.g("city","صنعاء"),geo=store.g("geo",null),fav=store.g("fav",[]),nf=store.g("nf",{on:false,pr:true,int:60,last:0,sound:"soft_chime"}),fs=store.g("fs",26),cur="home",imm=false,param=null,tick,ch=null,nfp="",pm=store.g("pm",0),adj=store.g("adj",[0,0,0,0,0]);
const nz=t=>t.replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640]/g,"").replace(/[أإآٱ]/g,"ا").replace(/ى/g,"ي");
const QD=Q.map((sv,i)=>{if(i==0)return sv;const w=sv[0].split(" ");return nz(w.slice(0,4).join(" "))=="بسم الله الرحمن الرحيم"?[w.slice(4).join(" ")].concat(sv.slice(1)):sv});
const MQW={"الم":"الٓمٓ","المص":"الٓمٓصٓ","الر":"الٓر","المر":"الٓمٓر","كهيعص":"كٓهيعٓصٓ","طسم":"طسٓمٓ","طس":"طسٓ","يس":"يسٓ","ص":"صٓ","حم":"حمٓ","عسق":"عٓسٓقٓ","ق":"قٓ","ن":"نٓ"};
[[2,1],[3,1],[7,1],[10,1],[11,1],[12,1],[13,1],[14,1],[15,1],[19,1],[26,1],[27,1],[28,1],[29,1],[30,1],[31,1],[32,1],[36,1],[38,1],[40,1],[41,1],[42,1],[42,2],[43,1],[44,1],[45,1],[46,1],[50,1],[68,1]].forEach(([a,b])=>{const w=QD[a-1][b-1].split(" ");if(MQW[w[0]]){w[0]=MQW[w[0]];QD[a-1][b-1]=w.join(" ")}});
const ALLAH=/^(?:[وف]?ا?[بت]?ا?لله|اللهم)$/,DNAMES=/^[وف]?(?:[بك]ال|لل|ال)(?:رحمن|رحيم|غفور|غفار|ودود|رزاق|قهار|وهاب|فتاح|عليم|قيوم|سميع|خبير|حليم|تواب|قدوس|لطيف|رؤوف|شكور|حميد|قدير|وكيل|واسع|مقيت|رقيب|مجيب)$/,DNCTX=/^[وف]?(?:[بك]ال|لل|ال)(حكيم|عزيز)$/,DNBAD={حكيم:["الذكر","القران","الكتاب"],عزيز:["امراة","امرات","ايها"]},qh=t=>{const ws=String(t).split(" ");return ws.map((w,i)=>{const n=nz(w);let d=ALLAH.test(n)||DNAMES.test(n);if(!d){const m=DNCTX.exec(n);if(m){const pv=i?nz(ws[i-1]).replace(/^[وف]/,""):"";d=!DNBAD[m[1]].includes(pv)}}return d?'<span class="al">'+esc(w)+'</span>':esc(w)}).join(" ")};
const JUZ=[[1, 1], [2, 142], [2, 253], [3, 92], [4, 24], [4, 148], [5, 83], [6, 111], [7, 88], [8, 41], [9, 94], [11, 6], [12, 53], [15, 1], [17, 1], [18, 75], [21, 1], [23, 1], [25, 21], [27, 56], [29, 46], [33, 31], [36, 28], [39, 32], [41, 47], [46, 1], [51, 31], [58, 1], [67, 1], [78, 1]];
const SN="الفاتحة:7,البقرة:286,آل عمران:200,النساء:176,المائدة:120,الأنعام:165,الأعراف:206,الأنفال:75,التوبة:129,يونس:109,هود:123,يوسف:111,الرعد:43,إبراهيم:52,الحجر:99,النحل:128,الإسراء:111,الكهف:110,مريم:98,طه:135,الأنبياء:112,الحج:78,المؤمنون:118,النور:64,الفرقان:77,الشعراء:227,النمل:93,القصص:88,العنكبوت:69,الروم:60,لقمان:34,السجدة:30,الأحزاب:73,سبأ:54,فاطر:45,يس:83,الصافات:182,ص:88,الزمر:75,غافر:85,فصلت:54,الشورى:53,الزخرف:89,الدخان:59,الجاثية:37,الأحقاف:35,محمد:38,الفتح:29,الحجرات:18,ق:45,الذاريات:60,الطور:49,النجم:62,القمر:55,الرحمن:78,الواقعة:96,الحديد:29,المجادلة:22,الحشر:24,الممتحنة:13,الصف:14,الجمعة:11,المنافقون:11,التغابن:18,الطلاق:12,التحريم:12,الملك:30,القلم:52,الحاقة:52,المعارج:44,نوح:28,الجن:28,المزمل:20,المدثر:56,القيامة:40,الإنسان:31,المرسلات:50,النبأ:40,النازعات:46,عبس:42,التكوير:29,الانفطار:19,المطففين:36,الانشقاق:25,البروج:22,الطارق:17,الأعلى:19,الغاشية:26,الفجر:30,البلد:20,الشمس:15,الليل:21,الضحى:11,الشرح:8,التين:8,العلق:19,القدر:5,البينة:8,الزلزلة:8,العاديات:11,القارعة:11,التكاثر:8,العصر:3,الهمزة:9,الفيل:5,قريش:4,الماعون:7,الكوثر:3,الكافرون:6,النصر:3,المسد:5,الإخلاص:4,الفلق:5,الناس:6".split(",").map(x=>x.split(":"));SN.forEach((x,i)=>x[1]=Q[i].length);
const TXT={1:SURAH[0],112:SURAH[2],113:SURAH[3],114:SURAH[4]};
const REM=["سُبْحَانَ اللَّهِ وَبِحَمْدِهِ","اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ","أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ وَأَتُوبُ إِلَيْهِ","رَبِّ زِدْنِي عِلْمًا","لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ","حَسْبِيَ اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ"];
const ICO={book:'<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M8 7h7"/>',doc:'<path d="M6 3h9l4 4v14H6z"/><path d="M9 11h7M9 15h7"/>',moon:'<path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/>',list:'<path d="M4 6h16M4 12h16M4 18h10"/>',hands:'<path d="M12 21c-5-2-8-6-8-10l4 2 4-6 4 6 4-2c0 4-3 8-8 10z"/>',sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2"/>',heart:'<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>',beads:'<circle cx="12" cy="5" r="2"/><circle cx="18" cy="10" r="2"/><circle cx="16" cy="17" r="2"/><circle cx="8" cy="17" r="2"/><circle cx="6" cy="10" r="2"/>',clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',home:'<path d="M3 11l9-8 9 8v10H3z"/>',bell:'<path d="M6 16v-5a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 21h4"/>',compass:'<circle cx="12" cy="12" r="9"/><path d="M15 9l-2 6-4 0 2-6z"/>',gear:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2"/>'};
const svg=k=>'<svg class="i" viewBox="0 0 24 24" aria-hidden="true">'+ICO[k]+'</svg>';
const TILES=[["quran","القرآن الكريم","book"],["hadith","الأحاديث النبوية","doc"],["story","القصص الإسلامية","moon"],["tafsir","التفسير والتدبر","list"],["dua","الأدعية","hands"],["adhkar","الأذكار","sun"],["favs","المفضلة","heart"],["tasbih","المسبحة الإلكترونية","beads"],["pray","مواقيت الصلاة","clock"]];
const NAVS=[["home","الرئيسية"],["calendar","التقويم الهجري"],["qibla","القبلة"],["favs","المفضلة"],["settings","الإعدادات"]];
const NI={home:"home",calendar:"clock",qibla:"compass",favs:"heart",settings:"gear"};
const TITLES={khatma:"ختمتي",quran:"القرآن الكريم",reader:"القرآن الكريم",tafsir:"التفسير والتدبر",hadith:"الأحاديث النبوية",story:"القصص الإسلامية",dua:"الأدعية",adhkar:"الأذكار",tasbih:"المسبحة الإلكترونية",pray:"مواقيت الصلاة",qibla:"القبلة",calendar:"التقويم الهجري",favs:"المفضلة",notif:"الإشعارات",settings:"الإعدادات"};
const LOGO='<svg viewBox="0 0 40 40" width="38" height="38" aria-hidden="true"><defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3D8BFF"/><stop offset="1" stop-color="#0B2A7A"/></linearGradient></defs><rect width="40" height="40" rx="10" fill="url(#lg)"/><path d="M8 35V19C8 12 14 7 20 4c6 3 12 8 12 15v16" fill="none" stroke="#E8C77A" stroke-width="1.4"/><path d="M14 9a4.5 4.5 0 1 0 3.2 7.7A3.7 3.7 0 0 1 14 9z" fill="#F7EBC7"/><path d="M15 27a5 5 0 0 1 10 0z" fill="#CFE2FF"/><path d="M20 36c-3-2-7-2-10-1.2V29c3-.8 7-.8 10 1.2 3-2 7-2 10-1.2v5.8C27 34 23 34 20 36z" fill="#fff"/></svg>';
const HEART='<svg viewBox="0 0 24 24"><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/></svg>';
function loc(){if(city==="موقعي"&&geo)return [geo.lat,geo.lng,-new Date().getTimezoneOffset()/60];return CITIES[city]||CITIES["صنعاء"]}
function pray(v){
 const [la,ln,tz]=loc(),now=new Date(),h=ptimes(now,la,ln,tz).map(x=>((x%24)+24)%24);
 const g=now.toLocaleDateString("ar",{weekday:"long",day:"numeric",month:"long",year:"numeric"});let hj="";try{hj=new Intl.DateTimeFormat("ar-SA-u-ca-islamic-umalqura",{day:"numeric",month:"long",year:"numeric"}).format(now)}catch(e){}
 v.innerHTML='<div class="banner big">'+SCENE+'<div class="bn"><b>'+city+'</b><span>'+g+'</span><span>'+hj+'</span></div></div><div class="card hero"><small>الصلاة القادمة</small><div class="t" id="pn"></div><div class="c" id="pc"></div><div class="bar" style="background:rgba(255,255,255,.3);margin:12px 4px 0"><i id="pb" style="background:#fff;width:0"></i></div></div><div class="card" id="pl"></div><div class="chips" style="justify-content:center"><select id="ct" aria-label="المدينة">'+Object.keys(CITIES).concat(geo?["موقعي"]:[]).map(c=>'<option '+(c==city?"selected":"")+'>'+c+'</option>').join("")+'</select><button class="chip" id="gp">استخدم موقعي</button></div><div class="btns"><button id="qb">القبلة</button><button id="nb">التنبيه بالأذان</button></div><p class="t3" style="text-align:center">الحساب بطريقة أم القرى تقريبًا؛ تحقق من التقويم المحلي لديك.</p>';
 $("#ct").onchange=e=>{city=e.target.value;store.s("city",city);render();schedulePrayerNotifications()};
 $("#gp").onclick=()=>{navigator.geolocation?navigator.geolocation.getCurrentPosition(p=>{geo={lat:p.coords.latitude,lng:p.coords.longitude};store.s("geo",geo);city="موقعي";store.s("city",city);render();schedulePrayerNotifications()},()=>toast("تعذّر تحديد الموقع، اختر مدينتك من القائمة")):toast("المتصفح لا يدعم تحديد الموقع")};
 $("#qb").onclick=()=>go("qibla");$("#nb").onclick=()=>go("notif");
 const IC={d:'<svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="var(--gold)"/><path d="M7 12.5l3.2 3.2L17 9" fill="none" stroke="var(--onacc)" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',n:'<svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="none" stroke="var(--gold)" stroke-width="2"/><circle cx="12" cy="12" r="4" fill="var(--gold)"/></svg>',u:'<svg width="22" height="22" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="none" stroke="var(--mute)" stroke-width="1.6" opacity=".6"/></svg>'};
 const upd=()=>{const n=new Date(),cur=n.getHours()+n.getMinutes()/60+n.getSeconds()/3600,idx=h.findIndex(x=>x>cur),nx=idx<0?0:idx,pv=nx===0?4:nx-1,tgt=h[nx];
  let diff=tgt-cur;if(diff<0)diff+=24;let span=tgt-h[pv];if(span<=0)span+=24;let el=cur-h[pv];if(el<0)el+=24;
  const s=Math.round(diff*3600),p=x=>String(x).padStart(2,"0");
  $("#pn").textContent=PN[nx]+" "+fmt(tgt);$("#pc").textContent="بعد "+p(Math.floor(s/3600))+":"+p(Math.floor(s%3600/60))+":"+p(s%60);
  $("#pb").style.width=Math.min(100,Math.max(0,el/span*100))+"%";
  $("#pl").innerHTML=PN.map((x,i)=>'<div class="row'+(i==nx?" now":"")+'"><span style="display:flex;align-items:center;gap:10px">'+(idx<0||i<idx?IC.d:i==nx?IC.n:IC.u)+x+'</span><span>'+fmt(h[i])+'</span></div>').join("")};
 upd();tick=setInterval(upd,1000)}
function dhikr(v,m){
 const D=m=="d",K=D?"secd":"sec",ks=D?["من القرآن"].concat(Object.keys(DU2)):Object.keys(ADHKAR);
 let sec=store.g(K,"الكل");if(sec!="الكل"&&ks.indexOf(sec)<0)sec="الكل";
 const DA=DUAA.concat(DQ),hd=s=>'<h3 style="margin:14px 4px 6px;color:var(--gold)">'+s+'</h3>';
 const body=(s,cnt,DT)=>s=="من القرآن"?DA.map(d=>`<div class="card"><div class="ar">${d[0]}</div><div class="t3">${d[1]}</div></div>`).join(""):DU2[s]?DU2[s].map(d=>`<div class="card"><div class="ar">${d}</div></div>`).join(""):
  ADHKAR[s].map((d,i)=>{const key=s+i,c=cnt[key]||0;if(c>=d[1]&&!DT[key]){DT[key]=Date.now();store.s("dt",DT)}return `<div class="card"><div class="ar">${d[0]}</div><div class="bar"><i style="width:${Math.min(100,c/d[1]*100)}%"></i></div><div class="row"><button class="chip" data-i="${key}" data-m="${d[1]}">${c>=d[1]?"✓ تم":"سبّح"}</button><span class="t3">${c} / ${d[1]}</span></div></div>`}).join("");
 const draw=()=>{const cnt=store.g("dc",{}),DT=store.g("dt",{}),now=Date.now();let ch2=false;
  Object.keys(DT).forEach(k=>{if(now-DT[k]>=864e5){delete DT[k];delete cnt[k];ch2=true}});if(ch2){store.s("dc",cnt);store.s("dt",DT)}
  v.innerHTML='<div class="chips hs" id="dk">'+["الكل"].concat(ks).map(k=>`<button class="chip ${k==sec?"on":""}" data-k="${k}">${k}</button>`).join("")+'</div>'+(sec=="الكل"?ks.map(s=>hd(s)+body(s,cnt,DT)).join(""):body(sec,cnt,DT));
  {const hc=$("#dk"),on=hc.querySelector(".on");if(on){const a=on.getBoundingClientRect(),z=hc.getBoundingClientRect();hc.scrollLeft+=(a.left+a.width/2)-(z.left+z.width/2)}}
  v.querySelectorAll("[data-k]").forEach(b=>b.onclick=()=>{sec=b.dataset.k;store.s(K,sec);draw();v.scrollTop=0});
  v.querySelectorAll("[data-i]").forEach(b=>b.onclick=()=>{const c=store.g("dc",{});if((c[b.dataset.i]||0)<+b.dataset.m)c[b.dataset.i]=(c[b.dataset.i]||0)+1;store.s("dc",c);const y=v.scrollTop;draw();v.scrollTop=y})};draw()}
const hst=x=>{x=nz(x).replace(/[^\u0621-\u064a]/g,"");if(x.length>3)x=x.replace(/^[وف]/,"");if(x.length>3)x=x.replace(/^[بلك]/,"");if(x.length>3)x=x.replace(/^ال/,"");return x};
const HFN=[["لا", "حرف نفي أو نهي بحسب السياق"], ["من", "اسم موصول بمعنى الذي، أو حرف جر"], ["في", "حرف جر يفيد الظرفية"], ["على", "حرف جر يفيد الاستعلاء"], ["إلى", "حرف جر يفيد انتهاء الغاية"], ["عن", "حرف جر يفيد المجاوزة"], ["ما", "اسم موصول بمعنى الذي، أو حرف نفي"], ["إن", "حرف توكيد"], ["أن", "حرف مصدري ينصب الفعل"], ["إنما", "أداة حصر وتأكيد"], ["أو", "حرف عطف يفيد التخيير"], ["ثم", "حرف عطف يفيد الترتيب والتراخي"], ["قال", "فعل ماض بمعنى تكلم"], ["قالوا", "قال الجماعة"], ["قلنا", "قلنا نحن"], ["إذا", "أداة شرط تفيد الزمن"], ["كان", "فعل ماض ناقص"], ["حتى", "حرف غاية بمعنى إلى أن"], ["لو", "حرف شرط"], ["كل", "اسم يفيد الشمول والعموم"], ["لم", "حرف نفي وجزم"], ["هذا", "اسم إشارة للمفرد القريب"], ["ذلك", "اسم إشارة للبعيد"], ["الذي", "اسم موصول للمفرد المذكر"], ["التي", "اسم موصول للمفردة المؤنثة"], ["يا", "حرف نداء"], ["هو", "ضمير غائب للمذكر"], ["أنا", "ضمير المتكلم"], ["لكن", "حرف استدراك"], ["بل", "حرف إضراب"], ["قد", "حرف تحقيق أو تقليل"], ["له", "جار ومجرور: اللام حرف جر والهاء ضمير الغائب"], ["الله", "لفظ الجلالة، اسم الرب سبحانه وتعالى"], ["لله", "اللام حرف جر ولفظ الجلالة: الله سبحانه وتعالى"], ["رسول", "المبعوث بالرسالة"], ["ﷺ", "صلى الله عليه وسلم"]],hfn={};HFN.forEach(a=>hfn[hst(a[0])]=a[1]);
const hFind=(h,w)=>{const k=hst(w);return h.w.find(e=>e[0].split(" ").some(y=>hst(y)==k))||(k&&hfn[k]?[w.replace(/[،؛.:؟!«»()"]/g,""),hfn[k]]:null)};
function hSheet(h,w){const sh=$("#sheet"),e=hFind(h,w),t=x=>'<h3 style="margin:10px 0 6px;color:var(--gold)">'+x+'</h3>';
 sh.innerHTML='<div class="sb" id="sb"></div><div class="sc2" role="dialog" aria-label="معنى الكلمة"><div class="grab"></div><div class="q1" style="font-size:28px;line-height:1.9;text-align:center;color:var(--gold)">'+esc(w.replace(/[،؛.:؟!«»()"]/g,""))+'</div>'+t("المعنى")+(e?'<p class="tt" style="margin:0"><b>'+esc(e[0])+':</b> '+esc(e[1])+'</p>':'<p class="tt t3" style="margin:0">لم يرد شرح خاص لهذه الكلمة في الكتاب.</p>')+t("راوي الحديث")+'<p class="tt" style="margin:0">'+esc(h.r)+'</p>'+t("قصة الحديث")+'<p class="tt" style="margin:0">'+esc(h.q)+'</p><div class="btns" style="margin-top:12px"><button id="scl">إغلاق</button></div></div>';sh.hidden=false;$("#sb").onclick=closeSheet;$("#scl").onclick=closeSheet}
function hadith(v){let c=Math.min(store.g("hch",-1),HCH.length);
 const draw=()=>{const n=HCH.length;
  v.innerHTML='<input id="hsearch" class="srch" type="search" placeholder="ابحث في الأحاديث النبوية…" value="'+esc(hq)+'"><div class="chips hs" id="hc">'+["الكل"].concat(HCH,["أحاديث أخرى"]).map((x,j,_,i=j-1)=>'<button class="chip sg '+(i==c?"on":"")+'" data-c="'+i+'">'+x+'</button>').join("")+'</div><p class="t3" style="text-align:center;margin:0 0 4px">اضغط مطولًا على أي كلمة لمعناها وراوي الحديث وقصته</p><div id="hl">'+
  (c<n?H50.filter(h=>(c<0||h.c==c)&&(!hq||nz(h.t+" "+h.m+" "+h.r+" "+h.s).includes(nz(hq)))).map(h=>'<div class="card"><b class="ht">'+h.n+'. '+esc(h.t)+'</b><div class="t3">الراوي: '+esc(h.r)+'</div><div class="ar hdt">«'+h.m.split(" ").map((w,k)=>'<span class="hw" data-h="'+h.n+'" data-w="'+k+'">'+esc(w)+'</span>').join(" ")+'»</div><div class="t3">'+esc(h.s)+'</div></div>').join(""):HADITH.slice(3).filter(h=>!hq||nz(h.join(" ")).includes(nz(hq))).map(h=>'<div class="card"><div class="ar">«'+h[0]+'»</div><div class="t3">'+h[1]+'</div><p>'+h[2]+'</p></div>').join(""))+'</div>';
  v.querySelectorAll("[data-c]").forEach(b=>b.onclick=()=>{c=+b.dataset.c;store.s("hch",c);draw();v.scrollTop=0});
  {const hc=$("#hc"),on=hc&&hc.querySelector(".on");if(on){const a=on.getBoundingClientRect(),z=hc.getBoundingClientRect();hc.scrollLeft+=(a.left+a.width/2)-(z.left+z.width/2)}}
  const hs=$("#hsearch");if(hs)hs.oninput=e=>{hq=e.target.value;draw()};const hl=$("#hl");let tm=0,tg=null,sx=0,sy=0;const cn=()=>{clearTimeout(tm);if(tg){tg.classList.remove("press");tg=null}};
  hl.addEventListener("pointerdown",e=>{const el=e.target.closest(".hw");if(!el)return;sx=e.clientX;sy=e.clientY;tg=el;el.classList.add("press");tm=setTimeout(()=>{const h=H50.find(x=>x.n==+el.dataset.h),w=h.m.split(" ")[+el.dataset.w];cn();try{navigator.vibrate&&navigator.vibrate(30)}catch(x){}hSheet(h,w)},450)});
  hl.addEventListener("pointermove",e=>{if(tg&&Math.hypot(e.clientX-sx,e.clientY-sy)>10)cn()});
  ["pointerup","pointercancel","pointerleave"].forEach(x=>hl.addEventListener(x,cn));
  hl.addEventListener("contextmenu",e=>{if(e.target.closest(".hw"))e.preventDefault()})};
 draw()}
function story(v){let f=store.g("sf","الكل"),q="",pn="";const esc=x=>x.replace(/&/g,"&amp;").replace(/</g,"&lt;"),open={};
 const row="display:flex;gap:6px;overflow-x:auto;flex-wrap:nowrap;white-space:nowrap;padding:4px 0;scrollbar-width:none",sm="flex:none;padding:5px 11px;font-size:12px";
 const ok=s=>f=="الأنبياء"?(s.n&&(!pn||s.n==pn)):(f=="الكل"||(f=="طويلة"?s.k=="L":s.k=="S"));
 const draw=()=>{const L=STORIES.map((s,i)=>[s,i]).filter(([s])=>ok(s)&&(!q||(s.t+s.p.join(" ")).indexOf(q)>-1));
  v.innerHTML='<input id="sq" class="sg" type="search" placeholder="ابحث في القصص" value="'+esc(q)+'" style="width:100%;padding:10px 14px;margin:4px 0;font-size:15px;background:var(--card);color:var(--ink);border:1px solid var(--line);border-radius:20px"><div style="'+row+'">'+["الكل","طويلة","قصيرة","الأنبياء"].map(x=>'<button class="chip '+(x==f?"on":"")+'" style="flex:none" data-f="'+x+'">'+(x=="الأنبياء"?"قصص الأنبياء":x)+'</button>').join("")+'</div>'+(f=="الأنبياء"?'<div style="'+row+'">'+["",...PROPHETS].map(n=>'<button class="chip '+(n==pn?"on":"")+'" style="'+sm+'" data-p="'+n+'">'+(n||"الكل")+'</button>').join("")+'</div>':"")+'<p class="t3">'+ar(L.length)+' قصة</p>'+(L.map(([s,i])=>'<div class="card"><h2 data-o="'+i+'" style="cursor:pointer">'+s.t+'</h2>'+(open[i]?s.p.map(p=>'<p>'+esc(p)+'</p>').join("")+(s.s?'<p class="t3">المصدر: '+esc(s.s)+'</p>':""):'<p>'+esc(s.p.join(" ").slice(0,140))+'…</p>')+'<button class="chip" data-o="'+i+'">'+(open[i]?"إغلاق":"اقرأ القصة")+'</button></div>').join("")||'<div class="card"><p class="t3">لا قصة لهذا النبي بعد</p></div>');
  const on=v.querySelector("[data-p].on");if(on)on.scrollIntoView({inline:"center",block:"nearest"});
  v.querySelectorAll("[data-f]").forEach(b=>b.onclick=()=>{f=b.dataset.f;pn="";store.s("sf",f);draw()});
  v.querySelectorAll("[data-p]").forEach(b=>b.onclick=()=>{pn=b.dataset.p;draw()});
  v.querySelectorAll("[data-o]").forEach(b=>b.onclick=()=>{const i=b.dataset.o;open[i]=!open[i];const y=v.scrollTop;draw();v.scrollTop=y});
  const sq=$("#sq");sq.oninput=()=>{q=sq.value.trim();const p=sq.selectionStart;draw();const n=$("#sq");n.focus();n.setSelectionRange(p,p)}};draw()}
function tasbih(v){
 let c=store.g("tc",0),tot=store.g("tt",0),td=store.g("td",0);const dh=["سُبْحَانَ اللَّهِ","الْحَمْدُ لِلَّهِ","اللَّهُ أَكْبَرُ"];
 const draw=()=>{let b="";for(let k=0;k<33;k++){const a=k/33*2*Math.PI-Math.PI/2;b+='<circle cx="'+(130+112*Math.cos(a)).toFixed(1)+'" cy="'+(130+112*Math.sin(a)).toFixed(1)+'" r="8" fill="'+(k<c?"var(--gold)":"var(--card)")+'" stroke="var(--gold)" stroke-width="1.5"/>'}
 v.innerHTML='<div class="chips" style="justify-content:center">'+dh.map((t,k)=>'<button class="chip '+(k==td?"on":"")+'" data-d="'+k+'">'+t+'</button>').join("")+'</div><div style="position:relative;width:min(300px,86vw);margin:8px auto"><svg viewBox="0 0 260 260" style="width:100%;display:block" aria-hidden="true">'+b+'</svg><button class="dial2" id="d" aria-label="اضغط للتسبيح"><span style="font:700 54px Cairo,sans-serif">'+c+'</span><span class="t3">'+dh[td]+'</span></button></div><div class="btns"><button id="rs">تصفير</button></div><p class="t3" style="text-align:center">الإجمالي '+tot+'</p>';
 $("#d").onclick=()=>{c++;tot++;try{navigator.vibrate&&navigator.vibrate(c>=33?200:15)}catch(e){}if(c>=33)c=0;store.s("tc",c);store.s("tt",tot);draw()};
 $("#rs").onclick=()=>{c=0;store.s("tc",0);draw()};
 v.querySelectorAll("[data-d]").forEach(x=>x.onclick=()=>{td=+x.dataset.d;store.s("td",td);c=0;store.s("tc",0);draw()})};draw()}
const SCENE='<svg class="sc" viewBox="0 0 400 190" preserveAspectRatio="xMidYMax slice" aria-hidden="true"><defs><mask id="cm"><rect width="400" height="190" fill="#fff"/><circle cx="352" cy="38" r="15" fill="#000"/></mask></defs><circle cx="340" cy="44" r="17" fill="#FFF4D6" mask="url(#cm)"/><g fill="#fff" opacity=".8"><circle cx="40" cy="30" r="1.6"/><circle cx="90" cy="64" r="1.2"/><circle cx="290" cy="24" r="1.5"/><circle cx="240" cy="54" r="1"/><circle cx="378" cy="96" r="1.2"/></g><g fill="#fff" opacity=".35"><ellipse cx="60" cy="176" rx="90" ry="22"/><ellipse cx="335" cy="170" rx="100" ry="26"/></g><g fill="#EAF3FF"><path d="M130 190v-50h80v50z"/><path d="M130 140a40 40 0 0 1 80 0z"/><rect x="168" y="92" width="4" height="14"/><rect x="98" y="100" width="14" height="90"/><path d="M96 100l9-20 9 20z"/><rect x="228" y="100" width="14" height="90"/><path d="M226 100l9-20 9 20z"/></g><path d="M162 190v-18a8 8 0 0 1 16 0v18z" fill="#6FA8F5"/></svg>';
const BANNER='<div class="banner">'+SCENE+'<div class="bn"><b class="brand">أُنْس <span class="sep">|</span> <span class="lat">UNSS</span></b><span>أنيس قلبك إلى الله</span></div></div>';
function homePray(){const [la,ln,tz]=loc(),h=ptimes(new Date(),la,ln,tz).map(x=>((x%24)+24)%24);
 const upd=()=>{const e=$("#ps");if(!e)return;const n=new Date(),cur=n.getHours()+n.getMinutes()/60+n.getSeconds()/3600,idx=h.findIndex(x=>x>cur),nx=idx<0?0:idx;let d=h[nx]-cur;if(d<0)d+=24;const q=Math.round(d*3600),p=x=>String(x).padStart(2,"0");
  e.innerHTML='<div class="pt"><span>'+PN[nx]+' '+fmt(h[nx])+'</span><small>بعد '+p(Math.floor(q/3600))+':'+p(Math.floor(q%3600/60))+':'+p(q%60)+'</small></div><div class="pr">'+PN.map((x,i)=>'<span class="'+(i==nx?"on":"")+'"><small>'+x+'</small><b>'+fmt(h[i])+'</b></span>').join("")+'</div>'};
 $("#ps").onclick=()=>go("pray");upd();tick=setInterval(upd,1000)}
const ar=n=>String(n).replace(/\d/g,x=>"٠١٢٣٤٥٦٧٨٩"[x]);
function home(v){v.innerHTML=''+BANNER+'<div class="welcome"><svg class="i" viewBox="0 0 24 24" style="color:var(--gold)"><path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/></svg><div><h2>مرحباً بك</h2><p>في رفيقك اليومي لطاعة الله</p></div></div><button class="card pstrip" id="ps" aria-label="مواقيت الصلاة"></button><div class="card ayah"><small class="t3">آية اليوم</small><div class="q" style="font-size:24px">أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ</div><small class="t3">سورة الرعد : ٢٨</small></div>'+khatmaCard()+'<div class="grid">'+TILES.map(t=>'<button class="tile" data-g="'+t[0]+'"><svg viewBox="0 0 24 24" aria-hidden="true">'+ICO[t[2]]+'</svg>'+t[1]+'</button>').join("")+'</div>';v.querySelectorAll(".tile").forEach(b=>b.onclick=()=>go(b.dataset.g));homePray();const kc=$("#kc");if(kc)kc.onclick=()=>go("khatma")}

const esc=t=>String(t).replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));
const BMI='<svg class="i" viewBox="0 0 24 24" style="width:20px;height:20px" aria-hidden="true"><path d="M6 3h12v18l-6-4-6 4z"/></svg>';
let IDX=null,qtab="s",qq="",hq="";const idx=()=>IDX||(IDX=QD.map(x=>x.map(nz))),done=()=>store.g("done",[]);
function markDone(i,on){let d=done();const has=d.includes(i);if(on&&!has){d.push(i);if(d.length>=114){store.s("done",[]);celebrate("ما شاء الله، أتممت قراءة جميع السور! بدأت دورة جديدة بدون علامات");return "reset"}store.s("done",d);toast("أتممت سورة "+SN[i-1][0]+" — قرأت "+ar(d.length)+" من ١١٤ سورة")}else if(!on&&has){store.s("done",d.filter(x=>x!=i))}}
function markBm(){document.querySelectorAll(".v.bm").forEach(e=>e.classList.remove("bm"));const b=store.g("bm",null),e=b&&document.querySelector('.v[data-s="'+b.s+'"][data-n="'+b.a+'"]');if(e)e.classList.add("bm")}
function saveBm(i,n){store.s("bm",{s:i,a:n});markBm();toast("تم حفظ العلامة: سورة "+SN[i-1][0]+" — الآية "+ar(n))}
function topVerse(v){const r=v.getBoundingClientRect(),sec=[...v.querySelectorAll(".sw")].find(e=>e.getBoundingClientRect().bottom>r.top+40);if(!sec)return [1,1];for(const e of sec.querySelectorAll(".v")){if(e.getBoundingClientRect().bottom>r.top+60)return [+sec.dataset.s,+e.dataset.n]}return [+sec.dataset.s,1]}
function closeSheet(){const sh=$("#sheet");sh.hidden=true;sh.innerHTML=""}
function openSheet(i,n){const sh=$("#sheet");sh.innerHTML='<div class="sb" id="sb"></div><div class="sc2" role="dialog" aria-label="تفسير الآية"><div class="grab"></div><div class="t3">سورة '+SN[i-1][0]+' — الآية '+ar(n)+'</div><div class="q1" style="font-size:22px;line-height:2.1">'+qh(QD[i-1][n-1])+'</div><h3 style="margin:8px 0;color:var(--gold)">التفسير الميسر</h3><p class="tt" style="margin:0 0 12px">'+esc(T[i-1][n-1])+'</p><div class="btns"><button id="sbm">حفظ علامة هنا</button><button id="scl">إغلاق</button></div></div>';sh.hidden=false;
 $("#sb").onclick=closeSheet;$("#scl").onclick=closeSheet;$("#sbm").onclick=()=>{saveBm(i,n);closeSheet()}}
addEventListener("keydown",e=>{if(e.key=="Escape")closeSheet()});
function quran(v,mode){const t=mode=="t",bm=store.g("bm",null),last=store.g("last",0),dn=done(),vc=dn.reduce((a,i)=>a+Q[i-1].length,0);
 const item=i=>'<button class="it" data-s="'+i+'"><span class="no">'+i+'</span><span><b>سورة '+SN[i-1][0]+'</b><small>'+SN[i-1][1]+(+SN[i-1][1]<=10?' آيات':' آية')+'</small></span>'+(dn.includes(i)?'<span class="ok">✓</span>':'')+'</button>';
 v.innerHTML=(t?'<p class="t3">اختر سورة لعرض تفسير كل آية.</p>':khatmaCard()+'<div class="card"><div class="row" style="border:0"><b>تقدّمك في القراءة</b><span class="t3">'+ar(dn.length)+' من ١١٤ سورة · '+ar(vc)+' آية</span></div><div class="bar"><i style="width:'+Math.round(vc/6236*100)+'%"></i></div></div>'+(bm?'<button class="it sm" id="lr"><span class="no">↻</span><span><b>متابعة القراءة</b><small>سورة '+SN[bm.s-1][0]+' — الآية '+ar(bm.a)+'</small></span></button>':last?'<button class="it sm" id="lr"><span class="no">↻</span><span><b>متابعة القراءة</b><small>سورة '+SN[last-1][0]+'</small></span></button>':''))
 +'<input id="qs" class="srch" type="search" placeholder="ابحث عن سورة أو آية…" aria-label="بحث" value="'+esc(qq)+'">'
 +(t?'':'<div class="chips" style="justify-content:center"><button class="chip '+(qtab=="s"?"on":"")+'" data-q="s">السور</button><button class="chip '+(qtab=="j"?"on":"")+'" data-q="j">الأجزاء</button></div>')+'<div id="ql"></div>';
 const fill=()=>{const q=nz(qq.trim()),L=$("#ql");let h="";
  if(q.length>=2){const ms=SN.map((x,i)=>i+1).filter(i=>nz(SN[i-1][0]).includes(q));h+=ms.map(item).join("");
   let c=0,r="";const ix=idx();for(let i=0;i<114&&c<60;i++)for(let k=0;k<ix[i].length&&c<60;k++)if(ix[i][k].includes(q)){c++;r+='<button class="it" data-s="'+(i+1)+'" data-a="'+(k+1)+'"><span class="no">'+(i+1)+'</span><span><b>سورة '+SN[i][0]+' — الآية '+ar(k+1)+'</b><small>'+esc(QD[i][k].slice(0,110))+'</small></span></button>'}
   h+=r?'<p class="t3">نتائج الآيات'+(c>=60?' (أول ٦٠ نتيجة)':'')+'</p>'+r:(ms.length?'':'<p class="t3">لا توجد نتائج.</p>')}
  else if(qtab=="j"&&!t)h=JUZ.map((j,k)=>'<button class="it" data-s="'+j[0]+'" data-a="'+j[1]+'"><span class="no">'+ar(k+1)+'</span><span><b>الجزء '+ar(k+1)+'</b><small>يبدأ من سورة '+SN[j[0]-1][0]+' — الآية '+ar(j[1])+'</small></span></button>').join("");
  else h=SN.map((x,i)=>item(i+1)).join("");
  L.innerHTML=h;L.querySelectorAll(".it").forEach(b=>b.onclick=()=>go("reader",{s:+b.dataset.s,a:b.dataset.a?+b.dataset.a:undefined,m:t?"t":"r"}))};
 $("#qs").oninput=e=>{qq=e.target.value;fill()};v.querySelectorAll("[data-q]").forEach(b=>b.onclick=()=>{qtab=b.dataset.q;quran(v,mode)});
 const lr=$("#lr");if(lr)lr.onclick=()=>go("reader",bm?{s:bm.s,a:bm.a}:{s:last});const kc=$("#kc");if(kc)kc.onclick=()=>go("khatma");fill()}
const juzOf=(s,a)=>{let j=1;JUZ.forEach((x,k)=>{if(s>x[0]||(s==x[0]&&a>=x[1]))j=k+1});return j};
function surahHTML(i,m){const s=SN[i-1],d=QD[i-1],tf=T[i-1],bm=store.g("bm",null);
 const vs=k=>'<span class="v'+(bm&&bm.s==i&&bm.a==k+1?" bm":"")+'" data-s="'+i+'" data-n="'+(k+1)+'">'+qh(d[k])+' <i class="vn">'+ar(k+1)+'</i></span>';
 return '<section class="sw" data-s="'+i+'"><div class="mushaf"><div class="stitle">✦ سورة '+s[0]+' ✦</div><div class="t3" style="text-align:center">'+s[1]+(+s[1]<=10?' آيات':' آية')+'</div>'+(i!=1&&i!=9?'<div class="q1 bsm">'+qh(Q[0][0])+'</div>':'')+(m=="t"?d.map((a,k)=>'<div class="tv"><div class="q1">'+vs(k)+'</div><p class="tt">'+esc(tf[k])+'</p></div>').join(""):'<div class="q1 qb2">'+d.map((a,k)=>vs(k)).join(" ")+'</div>')+'</div></section>'}
function reader(v){const P=typeof param=="object"&&param?param:{s:param},i=P.s,m=P.m||"r";store.s("last",i);kStart=gIdx(i,P.a||1);let nxt=i+1,cs=i,raf=0,ht=0;const t0=Date.now(),ign=new Set(),rs=x=>{if(x==="reset")[...$("#sws").children].forEach(e=>ign.add(+e.dataset.s))};
 v.innerHTML='<div class="qb"><div class="pos" id="pos"></div><div class="chips" style="justify-content:center"><button class="chip '+(m=="r"?"on":"")+'" id="m1">قراءة</button><button class="chip '+(m=="t"?"on":"")+'" id="m2">تفسير</button><button class="chip" id="fa1" aria-label="تصغير الخط">أ−</button><button class="chip" id="fa2" aria-label="تكبير الخط">أ+</button></div><p class="t3" style="text-align:center;margin:0 0 6px">اضغط مطولًا على آية لتفسيرها · اضغط مرتين على السورة لملء الشاشة</p><div id="sws">'+surahHTML(i,m)+'</div></div><button class="fab" id="fb" aria-label="حفظ علامة">'+BMI+' حفظ علامة</button>';
 const sws=$("#sws"),more=()=>{while(nxt<=114&&v.scrollHeight-v.scrollTop-v.clientHeight<2200){sws.insertAdjacentHTML("beforeend",surahHTML(nxt,m));nxt++}};
 const upd=real=>{more();const r=v.getBoundingClientRect(),secs=[...sws.children],sec=secs.find(e=>e.getBoundingClientRect().bottom>r.top+40)||secs[0];cs=+sec.dataset.s;let cn=1;
  for(const e of sec.querySelectorAll(".v")){if(e.getBoundingClientRect().bottom>r.top+60){cn=+e.dataset.n;break}}
  kSide(cs,cn);
  kAuto(real,cs,cn);const tot=QD[cs-1].length,dn=done().includes(cs);
  $("#pos").innerHTML='<span>سورة '+SN[cs-1][0]+' · الآية '+ar(cn)+' من '+ar(tot)+' · الجزء '+ar(juzOf(cs,cn))+'</span><button id="pd" class="'+(dn?"on":"")+'" aria-label="تمت قراءة السورة">'+(dn?"✓":"○")+'</button><i class="pb" style="width:'+Math.round(cn/tot*100)+'%"></i>';
  $("#pd").onclick=()=>{rs(markDone(cs,!done().includes(cs)));upd(false)};
  if(real)secs.forEach(e=>{const n=+e.dataset.s;if(e.getBoundingClientRect().bottom<=r.top+r.height*.65&&!ign.has(n)&&!done().includes(n))rs(markDone(n,true))});
  store.s("last",cs)};
 $("#m1").onclick=()=>go("reader",{s:cs,m:"r"});$("#m2").onclick=()=>go("reader",{s:cs,m:"t"});
 const sz=x=>{fs=Math.max(20,Math.min(40,fs+x));store.s("fs",fs);document.documentElement.style.setProperty("--qfs",fs+"px")};$("#fa1").onclick=()=>sz(-2);$("#fa2").onclick=()=>sz(2);
 $("#fb").onclick=()=>{const [a,b]=topVerse(v);saveBm(a,b)};
 const qb=v.querySelector(".qb");let tm=null,sx=0,sy=0,tg=null;
 const cancel=()=>{clearTimeout(tm);if(tg){tg.classList.remove("press");tg=null}};
 qb.addEventListener("pointerdown",e=>{const el=e.target.closest(".v");if(!el)return;sx=e.clientX;sy=e.clientY;tg=el;el.classList.add("press");tm=setTimeout(()=>{const a=+el.dataset.s,b=+el.dataset.n;cancel();try{navigator.vibrate&&navigator.vibrate(30)}catch(x){}openSheet(a,b)},450)});
 qb.addEventListener("pointermove",e=>{if(tg&&Math.hypot(e.clientX-sx,e.clientY-sy)>10)cancel()});
 ["pointerup","pointercancel","pointerleave"].forEach(x=>qb.addEventListener(x,cancel));
 qb.addEventListener("contextmenu",e=>{if(e.target.closest(".v"))e.preventDefault()});
 let lt=0,lx=0,ly=0,dx=0,dy=0,dtm=0;
 qb.addEventListener("pointerdown",e=>{dx=e.clientX;dy=e.clientY;dtm=Date.now()});
 qb.addEventListener("pointerup",e=>{if(e.target.closest("button,.pos"))return;const n=Date.now();if(n-dtm>300||Math.hypot(e.clientX-dx,e.clientY-dy)>10)return;
  if(n-lt<350&&Math.hypot(e.clientX-lx,e.clientY-ly)<40){lt=0;cancel();document.querySelectorAll(".v.press").forEach(x=>x.classList.remove("press"));try{getSelection().removeAllRanges()}catch(x){}imm=!imm;applyImm()}else{lt=n;lx=e.clientX;ly=e.clientY}});
 more();if(P.a){const e=v.querySelector('.v[data-s="'+i+'"][data-n="'+P.a+'"]');if(e)v.scrollTop+=e.getBoundingClientRect().top-v.getBoundingClientRect().top-70}
 upd(false);v.onscroll=()=>{const a=$("#pos"),b=$("#fb");if(a)a.classList.add("hide");if(b)b.classList.add("hide");clearTimeout(ht);ht=setTimeout(()=>{const x=$("#pos"),y=$("#fb");if(x)x.classList.remove("hide");if(y)y.classList.remove("hide")},900);if(raf)return;raf=requestAnimationFrame(()=>{raf=0;upd(Date.now()-t0>900)})}}
const dayw=n=>n==1?"يوم":n==2?"يومين":n<=10?ar(n)+" أيام":ar(n)+" يومًا";
const dkey=d=>d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
let KG=null,kStart=0,kd=30;const OFF=[];{let o=0;Q.forEach(x=>{OFF.push(o);o+=x.length})}const gIdx=(x,a)=>OFF[x-1]+a-1,KP=()=>store.g("kp",null);
function kidx(){if(KG)return KG;const st=[],cw=[0];let w=0;QD.forEach((sv,i)=>sv.forEach((t,k)=>{st.push([i+1,k+1]);w+=t.split(" ").length;cw.push(w)}));return KG={st,cw,W:w}}
const dsince=st=>{const a=st.split("-").map(Number),t=new Date();return Math.round((new Date(t.getFullYear(),t.getMonth(),t.getDate())-new Date(a[0],a[1]-1,a[2]))/864e5)};
function portion(k,off){const g=kidx(),rem=Math.max(1,k.D-dsince(k.st)-(off||0)),p=Math.min(k.p,6235),base=g.cw[p],target=(g.W-base)/rem;let e=p;if(rem==1)e=6235;else{while(e<6235&&g.cw[e+1]-base<target)e++}return {rem,start:p,end:e,words:g.cw[e+1]-g.cw[p]}}
const kTxt=(g,pt)=>{const a=g.st[pt.start],b=g.st[pt.end];return {a,b,t:"من سورة "+SN[a[0]-1][0]+" · الآية "+ar(a[1])+"<br>إلى سورة "+SN[b[0]-1][0]+" · الآية "+ar(b[1]),n:pt.end-pt.start+1,j:(pt.words/(g.W/30)).toFixed(1)}};
function celebrate(msg){toast(msg);try{navigator.vibrate&&navigator.vibrate([40,60,40])}catch(e){}if(matchMedia("(prefers-reduced-motion: reduce)").matches)return;const c=document.createElement("div");c.className="conf";const cl=["#2F7BEA","#6FD3FF","#E8C77A","#fff","#1E5AE0"];for(let i=0;i<26;i++){const p=document.createElement("i");p.style.cssText="left:"+Math.random()*100+"%;background:"+cl[i%5]+";animation-delay:"+Math.random()*.4+"s;--dx:"+((Math.random()-.5)*160)+"px";c.appendChild(p)}document.body.appendChild(c);setTimeout(()=>c.remove(),2300)}
function kDone(k){const pt=portion(k);k.p=pt.end+1;k.dd=dkey(new Date());store.s("kp",k);celebrate(k.p>=6236?"ختمة مباركة! تقبّل الله منك":"أتممت ورد اليوم، بارك الله فيك")}
function kFrac(x,n){const g=kidx(),k=KP(),gi=gIdx(x,n),live=g.cw[gi];if(k&&k.p<6236){const base=g.cw[k.p],end=g.cw[portion(k).end+1];return (live>base&&live<=end?live:base)/g.W}return live/g.W}
function kSide(x,n){const f=Math.max(0,Math.min(1,kFrac(x,n))),h=(f*100).toFixed(2)+"%",rem=Math.min(100,Math.max(0,Math.ceil((1-f)*100)));["#rpl","#rpr"].forEach(q=>{const e=$(q);if(!e)return;e.firstChild.style.height=h;const b=e.querySelector("b");if(b){b.style.top=h;b.style.transform="translateY(-"+h+")";b.textContent="باقي "+ar(rem)+"٪ للختمة"}})}
function kAuto(real,x,n){const k=KP();if(!k||!real||k.p>=6236||k.dd==dkey(new Date()))return;if(kStart<=portion(k).end&&gIdx(x,n)>=portion(k).end)kDone(k)}
function kmsg(){const k=KP();if(!k||k.p>=6236||k.dd==dkey(new Date()))return null;const g=kidx(),t=kTxt(g,portion(k));return "ورد الختمة اليوم: من سورة "+SN[t.a[0]-1][0]+" آية "+ar(t.a[1])+" إلى سورة "+SN[t.b[0]-1][0]+" آية "+ar(t.b[1])}
function khatmaCard(){const k=KP(),ic='<svg class="i" viewBox="0 0 24 24" aria-hidden="true">'+ICO.book+'</svg>';if(!k)return '<button class="card kcard sm" id="kc">'+ic+'<div><b>ابدأ ختمة القرآن</b><div class="t3">حدّد عدد الأيام وسنحدد لك وردك اليومي</div></div></button>';
 const g=kidx(),pc=Math.round(g.cw[Math.min(k.p,6236)]/g.W*100);if(k.p>=6236)return '<button class="card kcard sm" id="kc">'+ic+'<div><b>ما شاء الله، أتممت الختمة</b><div class="t3">اضغط لبدء ختمة جديدة</div></div></button>';
 const dn=k.dd==dkey(new Date()),t=kTxt(g,portion(k,dn?1:0));return '<button class="card kcard sm" id="kc">'+ic+'<div style="flex:1"><b>ختمتي · '+ar(pc)+'٪</b><div class="t3">'+(dn?"✓ أتممت ورد اليوم":"ورد اليوم: "+SN[t.a[0]-1][0]+" "+ar(t.a[1])+" ← "+SN[t.b[0]-1][0]+" "+ar(t.b[1]))+'</div><div class="bar"><i style="width:'+pc+'%"></i></div></div></button>'}
function khatma(v){const k=KP(),g=kidx();
 if(!k||k.p>=6236){const draw=()=>{const per=Math.ceil(6236/kd);$("#kpv").textContent="≈ "+ar(per)+" آية يوميًا (≈ "+ar((30/kd).toFixed(1))+" جزء)"};
  v.innerHTML=(k?'<div class="card" style="text-align:center"><h2>ما شاء الله، أتممت الختمة</h2><p class="t3">تقبّل الله منك. ابدأ ختمة جديدة متى شئت.</p></div>':'')+'<div class="card"><h2>ابدأ ختمتك</h2><p class="t3">اختر عدد الأيام وسأحدد لك وردك اليومي تلقائيًا، وأعدّله إذا تأخرت أو تقدمت.</p><div class="chips wrap">'+[7,15,30,60,90,180].map(x=>'<button class="chip '+(x==kd?"on":"")+'" data-d="'+x+'">'+ar(x)+' يومًا</button>').join("")+'</div><input id="kdi" class="srch" type="number" min="1" max="365" value="'+kd+'" aria-label="عدد الأيام"><p class="t3" id="kpv"></p><button class="bt" id="kst">ابدأ الختمة</button></div>';
  draw();v.querySelectorAll("[data-d]").forEach(b=>b.onclick=()=>{kd=+b.dataset.d;khatma(v)});$("#kdi").oninput=e=>{kd=Math.max(1,Math.min(365,+e.target.value||1));draw()};
  $("#kst").onclick=()=>{store.s("kp",{D:kd,st:dkey(new Date()),p:0,dd:""});khatma(v)};return}
 const dn=k.dd==dkey(new Date()),pt=portion(k,dn?1:0),t=kTxt(g,pt),ds=dsince(k.st),pc=Math.round(g.cw[k.p]/g.W*100),ideal=g.W*(ds+(dn?1:0))/k.D,df=(g.cw[k.p]-ideal)/(g.W/k.D),late=k.D-ds<=0;
 const stt=late?"انتهت المدة المحددة، يمكنك تمديدها":Math.abs(df)<.5?"أنت في الموعد":df>0?"أنت متقدم بنحو "+dayw(Math.round(df)):"أنت متأخر بنحو "+dayw(Math.round(-df))+"، وعدّلت وردك تلقائيًا";
 const rg=(p,tx)=>'<svg viewBox="0 0 80 80" width="110" height="110" aria-hidden="true"><circle cx="40" cy="40" r="34" fill="none" stroke="var(--line)" stroke-width="8"/><circle cx="40" cy="40" r="34" fill="none" stroke="var(--gold)" stroke-width="8" stroke-linecap="round" stroke-dasharray="213.6" stroke-dashoffset="'+(213.6*(1-p/100)).toFixed(1)+'" transform="rotate(-90 40 40)"/><text x="40" y="47" text-anchor="middle" font-size="19" font-weight="700" fill="currentColor">'+tx+'</text></svg>';
 v.innerHTML='<div class="card" style="text-align:center">'+rg(pc,ar(pc)+"٪")+'<h2>ختمتي</h2><div class="t3">اليوم '+ar(Math.min(ds+1,k.D))+' من '+ar(k.D)+' · المتبقي '+dayw(Math.max(0,k.D-ds-(dn?1:0)))+'</div><div style="color:var(--gold);font-weight:700;margin-top:4px">'+stt+'</div></div>'
 +'<div class="card nf"><b>'+(dn?"✓ أتممت ورد اليوم — ورد الغد":"ورد اليوم")+'</b><p class="ar" style="font-size:19px;margin:6px 0">'+t.t+'</p><div class="t3">≈ '+ar(t.n)+' آية · ≈ '+ar(t.j)+' جزء</div><div class="btns" style="margin-top:10px">'+(dn?'':'<button id="kgo">ابدأ القراءة</button><button id="kok">تم ورد اليوم</button>')+'</div></div>'
 +'<div class="btns"><button id="kex">تمديد ٧ أيام</button><button id="kcn">إلغاء الخطة</button></div>';
 const a=g.st[pt.start];if($("#kgo"))$("#kgo").onclick=()=>go("reader",{s:a[0],a:a[1]});if($("#kok"))$("#kok").onclick=()=>{kDone(k);khatma(v)};
 $("#kex").onclick=()=>{k.D+=7;store.s("kp",k);khatma(v)};let sure=0;$("#kcn").onclick=()=>{if(!sure){sure=1;$("#kcn").textContent="اضغط للتأكيد";return}store.s("kp",null);khatma(v)}}
function tafsir(v){quran(v,"t")}
function favs(v){v.innerHTML=fav.length?fav.map((t,k)=>'<div class="card"><div class="ar">'+t+'</div><button class="chip" data-k="'+k+'">حذف</button></div>').join(""):'<div class="card"><p class="t3">لا توجد عناصر في المفضلة بعد. اضغط على القلب في أي آية أو ذكر أو حديث لحفظه هنا.</p></div>';v.querySelectorAll("[data-k]").forEach(b=>b.onclick=()=>{fav.splice(+b.dataset.k,1);store.s("fav",fav);favs(v)})}
function favScan(v){v.querySelectorAll(".card").forEach(c=>{const e=c.querySelector(".ar,.q");if(!e||c.querySelector(".hb")||c.classList.contains("hero")||c.classList.contains("nf"))return;const t=e.textContent.trim(),b=document.createElement("button");b.className="hb";b.setAttribute("aria-label","المفضلة");const st=()=>{b.classList.toggle("on",fav.includes(t));b.innerHTML=HEART};st();b.onclick=()=>{fav=fav.includes(t)?fav.filter(x=>x!==t):fav.concat(t);store.s("fav",fav);st()};c.style.position="relative";c.appendChild(b)})}
function toast(t){const e=$("#toast");e.textContent=t;e.style.opacity=1;setTimeout(()=>e.style.opacity=0,6000)}
const LocalNotifs=()=>window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.LocalNotifications;
async function requestLocalPermission(){const L=LocalNotifs();if(!L)return false;try{let p=await L.checkPermissions();if(p.display!=="granted")p=await L.requestPermissions();return p.display==="granted"}catch(e){return false}}
const NICON={smallIcon:"ic_stat_anis",largeIcon:"ic_large_anis",iconColor:"#1E5AE0"};
const NOTIF_SOUNDS=[
 {id:"soft_chime",name:"رنين هادئ",file:"soft_chime.wav",desc:"نغمة خفيفة وناعمة"},
 {id:"gentle_bell",name:"جرس لطيف",file:"gentle_bell.wav",desc:"جرس هادئ وواضح"},
 {id:"bright_ping",name:"تنبيه واضح",file:"bright_ping.wav",desc:"نغمة قصيرة بارزة"},
 {id:"calm_tone",name:"نغمة هادئة",file:"calm_tone.wav",desc:"صوت مريح وبسيط"},
 {id:"double_note",name:"نغمتان متتاليتان",file:"double_note.wav",desc:"تنبيهان موسيقيان قصيران"}
];
const selectedNotifSound=()=>NOTIF_SOUNDS.find(x=>x.id===nf.sound)||NOTIF_SOUNDS[0];
const notifChannel=()=>"anis-reminders-"+selectedNotifSound().id;
const ADHAN_CHANNEL="anis-adhan-channel-v2";
let previewAudio=null;
function stopPreview(){if(previewAudio){try{previewAudio.pause();previewAudio.currentTime=0}catch(e){}previewAudio=null}}
function playPreview(file){stopPreview();previewAudio=new Audio("assets/"+file);previewAudio.volume=.9;previewAudio.play().catch(()=>toast("تعذّر تشغيل الصوت. جرّب بعد السماح بالصوت."))}
async function ensureNotifChannel(){
 const L=LocalNotifs();if(!L)return;
 const snd=selectedNotifSound();
 await L.createChannel({id:notifChannel(),name:"إشعارات أُنْس - "+snd.name,description:"تنبيهات الأذكار والتذكير",importance:5,sound:snd.file,vibration:true,visibility:1});
}
async function ensureAdhanChannel(){
 const L=LocalNotifs();if(!L)return;
 await L.createChannel({id:ADHAN_CHANNEL,name:"أذان الصلاة - أُنْس",description:"تنبيه الأذان عند دخول وقت الصلاة",importance:5,sound:"adhan.mp3",vibration:true,visibility:1});
}
async function exactAlarmOk(){const L=LocalNotifs();try{if(L&&L.checkExactNotificationSetting){const r=await L.checkExactNotificationSetting();return r.exact_alarm!=="denied"}}catch(e){}return true}
async function cancelOurNotifs(){
 const L=LocalNotifs();if(!L)return;
 try{const old=await L.getPending();const ids=(old.notifications||[]).filter(n=>n.id>=710000&&n.id<750000).map(n=>({id:n.id}));if(ids.length)await L.cancel({notifications:ids})}catch(e){}
}
async function permGranted(){const L=LocalNotifs();if(!L)return false;try{return (await L.checkPermissions()).display==="granted"}catch(e){return false}}
async function schedulePrayerNotifications(){
 const L=LocalNotifs();if(!L)return;
 if(!nf.en){await cancelOurNotifs();return}
 if(!(await permGranted()))return;
 try{
  await ensureNotifChannel();
  if(nf.ad!==false)await ensureAdhanChannel();
  await L.registerActionTypes({types:[{id:"prayer-followup",actions:[{id:"prayed",title:"نعم، صليت"},{id:"snooze",title:"ذكرني بعد 10 دقائق"}]}]});
  await cancelOurNotifs();
  const [la,ln,tz]=loc(),items=[],now=new Date();
  for(let day=0;day<7;day++){
   const d=new Date(now.getFullYear(),now.getMonth(),now.getDate()+day);
   const ts=ptimes(d,la,ln,tz);
   ts.forEach((h,i)=>{
    const mins=Math.round((((h%24)+24)%24)*60);
    const at=new Date(d);at.setHours(Math.floor(mins/60),mins%60,0,0);
    if(at<=now)return;
    const base=710000+day*20+i*2;
    if(nf.pr){
     items.push({id:base,title:"أُنْس | حان وقت الصلاة",body:"حان الآن وقت صلاة "+PN[i],schedule:{at,allowWhileIdle:true},channelId:notifChannel(),sound:selectedNotifSound().file,...NICON});
     const follow=new Date(at.getTime()+15*60000);
     items.push({id:base+1,title:"أُنْس | تذكير بالصلاة",body:"هل صليت صلاة "+PN[i]+"؟",schedule:{at:follow,allowWhileIdle:true},channelId:notifChannel(),sound:selectedNotifSound().file,actionTypeId:"prayer-followup",...NICON});
    }
    if(nf.ad!==false){
     items.push({id:730000+day*10+i,title:"أُنْس | حان وقت الأذان",body:"حان الآن وقت أذان صلاة "+PN[i],schedule:{at,allowWhileIdle:true},channelId:ADHAN_CHANNEL,sound:"adhan.mp3",ongoing:false,autoCancel:true,...NICON});
    }
   });
  }
  if(nf.on){for(let day=0;day<7;day++){const d=new Date(now.getFullYear(),now.getMonth(),now.getDate()+day),add=(h,m,id,title,body)=>{const at=new Date(d);at.setHours(h,m,0,0);if(at>now)items.push({id,title,body,schedule:{at,allowWhileIdle:true},channelId:notifChannel(),sound:selectedNotifSound().file,...NICON})};add(6,30,750000+day*3,"أذكار الصباح","هل قرأت أذكار الصباح اليوم؟");add(19,0,750001+day*3,"أذكار المساء","هل قرأت أذكار المساء؟");add([13,14,15,16][(day+now.getDate())%4],20,750002+day*3,"تذكير من أُنْس",REM[(day*3)%REM.length]);}}
  if(items.length)await L.schedule({notifications:items});
  if(!(await exactAlarmOk()))toast("لوصول الإشعارات والشاشة مطفأة: اضغط «السماح بالمنبهات الدقيقة» في صفحة الإشعارات");
 }catch(e){console.warn("Local notification scheduling failed",e);toast("تعذّر جدولة بعض التنبيهات. تحقق من أذونات الإشعارات والمنبّهات.")}
}
async function notify(t){
 toast(t);const L=LocalNotifs();
 if(L){const ok=await requestLocalPermission();if(ok){try{await ensureNotifChannel();await L.schedule({notifications:[{id:799999,title:"أُنْس | UNSS",body:t,channelId:notifChannel(),sound:selectedNotifSound().file,...NICON,schedule:{at:new Date(Date.now()+1000),allowWhileIdle:true}}]});return}catch(e){}}}
 try{if(window.Notification&&Notification.permission==="granted")new Notification("أُنْس | UNSS",{body:t,lang:"ar",dir:"rtl"})}catch(e){}
}
function chk(){if(LocalNotifs()||!nf.en)return;const n=Date.now();if(nf.on&&n-nf.last>=nf.int*60000){nf.last=n;store.s("nf",nf);notify(kmsg()||REM[Math.floor(Math.random()*REM.length)])}
 if(nf.pr){const [la,ln,tz]=loc(),d=new Date(),cm=d.getHours()*60+d.getMinutes();ptimes(d,la,ln,tz).forEach((x,i)=>{if(Math.round((((x%24)+24)%24)*60)===cm&&nfp!==d.toDateString()+i){nfp=d.toDateString()+i;notify("حان وقت صلاة "+PN[i])}})}}
setInterval(chk,30000);
const AU=new Audio("assets/adhan.mp3");AU.preload="auto";
function adhan(){try{AU.muted=false;AU.currentTime=0;AU.play().catch(()=>{})}catch(e){}}
document.addEventListener("click",()=>{if(!AU.paused)return;AU.muted=true;AU.play().then(()=>{AU.pause();AU.muted=false;AU.currentTime=0}).catch(()=>{})},{once:true});
const LNO=LocalNotifs();if(LNO){LNO.addListener("localNotificationActionPerformed",async ev=>{if(ev.actionId==="snooze"){try{await LNO.schedule({notifications:[{id:799998,title:"أُنْس | تذكير بالصلاة",body:"تذكير لطيف: هل صليت؟",channelId:notifChannel(),sound:selectedNotifSound().file,...NICON,schedule:{at:new Date(Date.now()+10*60000)}}]})}catch(e){}}});(async()=>{if(nf.en===undefined){nf.en=await permGranted()&&(nf.on||nf.pr!==false||nf.ad!==false);store.s("nf",nf)}schedulePrayerNotifications()})();document.addEventListener("visibilitychange",()=>{if(!document.hidden)schedulePrayerNotifications()})}
function notif(v){
 const sv=()=>store.s("nf",nf),en=!!nf.en,native=!!LocalNotifs();
 const tg=(id,on,dis)=>(on=on&&(dis?false:true)||(id==='n0'&&on),'<button type="button" role="switch" class="tgl'+(on?' on':'')+'" id="'+id+'" aria-checked="'+(on?'true':'false')+'"'+(dis?' disabled':'')+'><i></i></button>');
 const row=(t,sub,ctl)=>'<div class="setting-row"><div><b>'+t+'</b>'+(sub?'<small>'+sub+'</small>':'')+'</div>'+ctl+'</div>';
 const sounds=NOTIF_SOUNDS.map(s=>{const a=s.id===selectedNotifSound().id;return '<button type="button" class="sound-option'+(a?' selected':'')+'" data-sound="'+s.id+'" aria-pressed="'+a+'"><span class="sound-radio">'+(a?'✓':'')+'</span><span class="sound-copy"><b>'+s.name+'</b></span><span class="sound-play">▶</span></button>'}).join("");
 v.innerHTML=
 '<section class="card notif-card master"><div class="setting-row"><div><b>الإشعارات</b><small>'+(en?'مفعّلة':'متوقفة')+'</small></div>'+tg("n0",en,false)+'</div></section>'+
 '<section class="card notif-card'+(en?'':' off')+'">'+
  row("إشعار وقت الصلاة","",tg("n2",nf.pr!==false,!en))+
  row("الأذان بصوت المؤذن","",'<span class="rowctl"><button type="button" class="pv" id="n6" aria-label="استمع إلى الأذان">▶</button>'+tg("n5",nf.ad!==false,!en)+'</span>')+
  row("أذكار الصباح 06:30 والمساء 19:00 + تذكير عشوائي بعد الظهر","",tg("n1",!!nf.on,!en))+
  
 '</section>'+
 '<section class="card notif-card'+(en?'':' off')+'"><div class="notif-section-head"><h2>صوت الإشعار</h2></div><div class="sound-list">'+sounds+'</div></section>'+
 (native?'<section class="card notif-card"><div class="setting-row"><div><b>المنبهات الدقيقة</b><small>لوصول الإشعارات في وقتها</small></div><button type="button" class="chip" id="n8">السماح</button></div></section>':'');
 const redraw=()=>{const y=v.scrollTop;notif(v);v.scrollTop=y};
 $("#n0").onclick=async()=>{
  if(!nf.en){
   if(native){const ok=await requestLocalPermission();if(!ok){toast("لم يتم السماح بالإشعارات. فعّلها من إعدادات أندرويد.");return}}
   nf.en=true;nf.pr=true;nf.ad=true;nf.on=true;nf.last=Date.now();sv();await schedulePrayerNotifications();
  }else{nf.en=false;sv();stopPreview();await schedulePrayerNotifications()}
  redraw();
 };
 const sub=(id,fn)=>{const e=$("#"+id);if(e)e.onclick=async()=>{if(!nf.en)return;fn();sv();await schedulePrayerNotifications();redraw()}};
 sub("n2",()=>{nf.pr=nf.pr===false});
 sub("n5",()=>{nf.ad=nf.ad===false});
 sub("n1",()=>{nf.on=!nf.on;if(nf.on)nf.last=Date.now()});
 const n3=$("#n3");if(n3)n3.onchange=async e=>{nf.int=+e.target.value;nf.last=Date.now();sv();await schedulePrayerNotifications()};
 v.querySelectorAll("[data-sound]").forEach(b=>b.onclick=async()=>{
  if(!nf.en)return;
  nf.sound=b.dataset.sound;sv();
  v.querySelectorAll("[data-sound]").forEach(x=>{const a=x.dataset.sound===nf.sound;x.classList.toggle("selected",a);x.setAttribute("aria-pressed",String(a));x.querySelector(".sound-radio").textContent=a?"✓":""});
  playPreview(selectedNotifSound().file);
  await schedulePrayerNotifications();
 });
 const pv=$("#n6");if(pv)pv.onclick=()=>{if(previewAudio&&!previewAudio.paused){stopPreview();pv.textContent="▶"}else{playPreview("adhan.mp3");pv.textContent="■";previewAudio.onended=()=>{pv.textContent="▶"}}};
 const n8=$("#n8");if(n8)n8.onclick=async()=>{const L=LocalNotifs();try{if(L&&L.changeExactNotificationSetting){await L.changeExactNotificationSetting();return}}catch(e){}toast("هذا الخيار متاح داخل تطبيق أندرويد فقط")};
}
function calendar(v){const now=new Date(),months=["محرم","صفر","ربيع الأول","ربيع الآخر","جمادى الأولى","جمادى الآخرة","رجب","شعبان","رمضان","شوال","ذو القعدة","ذو الحجة"],parts=d=>new Intl.DateTimeFormat("en-u-ca-islamic-umalqura",{month:"numeric",year:"numeric"}).formatToParts(d),cp=parts(now);let selected=store.g("hijriTarget",{m:+cp.find(x=>x.type==="month").value,y:+cp.find(x=>x.type==="year").value});
const dateOf=(m,y)=>{for(let d=new Date(now.getFullYear()-1,0,1);d<new Date(now.getFullYear()+2,11,31);d.setDate(d.getDate()+1)){const p=parts(d);if(+p.find(x=>x.type==="month").value===m&&+p.find(x=>x.type==="year").value===y)return new Date(d)}return new Date(now)};
const draw=()=>{const today=new Intl.DateTimeFormat("ar-SA-u-ca-islamic-umalqura",{weekday:"long",day:"numeric",month:"long",year:"numeric"}).format(now),start=dateOf(selected.m,selected.y),next=dateOf(selected.m===12?1:selected.m+1,selected.m===12?selected.y+1:selected.y),total=Math.round((next-start)/86400000),offset=start.getDay(),week=["ح","ن","ث","ر","خ","ج","س"];let monthGrid='<div class="card"><b>'+months[selected.m-1]+' '+selected.y+' هـ</b><div class="hijri-grid">'+week.map(x=>'<span class="hijri-week">'+x+'</span>').join("")+Array(offset).fill('<span></span>').join("")+Array.from({length:total},(_,i)=>'<span class="hijri-day">'+(i+1)+'</span>').join("")+'</div></div>';v.innerHTML='<div class="card hero"><small>تاريخ اليوم الهجري</small><div class="t">'+today+'</div><div class="c">تقويم أم القرى</div></div><div class="card"><h3>حدد الشهر والسنة</h3><div class="row"><label>الشهر</label><select id="hm">'+months.map((m,i)=>'<option value="'+(i+1)+'" '+(selected.m===i+1?'selected':'')+'>'+m+'</option>').join('')+'</select></div><div class="row"><label>السنة الهجرية</label><input id="hy" type="number" value="'+selected.y+'" style="width:110px"></div><button class="bt" id="hchoose">اعتماد الشهر</button></div>'+monthGrid+'<div class="card hijri-count"><small>المتبقي للشهر المحدد</small><div class="neon-count" id="hcount"></div><p id="hlabel" class="t3"></p></div><div class="card"><b>أشهر السنة الهجرية</b><div class="hijri-months">'+months.map((m,i)=>'<button class="chip" data-month="'+(i+1)+'">'+m+'</button>').join('')+'</div></div>';
const upd=()=>{let ms=dateOf(selected.m,selected.y)-Date.now(),c=$("#hcount"),l=$("#hlabel");if(!c)return;if(ms<=0){c.textContent="00 يوم · 00:00:00";l.textContent="بدأ الشهر المحدد بالفعل";return}let sec=Math.floor(ms/1000),days=Math.floor(sec/86400);sec%=86400;c.textContent=days+" يوم · "+[Math.floor(sec/3600),Math.floor(sec%3600/60),sec%60].map(x=>String(x).padStart(2,"0")).join(":");l.textContent="حتى بداية "+months[selected.m-1]+" "+selected.y+" هـ"};
$("#hchoose").onclick=()=>{selected={m:+$("#hm").value,y:+$("#hy").value};store.s("hijriTarget",selected);draw();scheduleHijriAlert()};v.querySelectorAll("[data-month]").forEach(x=>x.onclick=()=>{$("#hm").value=x.dataset.month;selected.m=+x.dataset.month;store.s("hijriTarget",selected);draw();scheduleHijriAlert()});upd();clearInterval(tick);tick=setInterval(upd,1000)};draw()}
async function scheduleHijriAlert(){const L=LocalNotifs(),t=store.g("hijriTarget",null);if(!L||!t)return;try{const now=new Date(),fmt=new Intl.DateTimeFormat("en-u-ca-islamic-umalqura",{month:"numeric",year:"numeric"});for(let d=new Date(now.getFullYear()-1,0,1);d<new Date(now.getFullYear()+2,11,31);d.setDate(d.getDate()+1)){const p=fmt.formatToParts(d);if(+p.find(x=>x.type==="month").value===t.m&&+p.find(x=>x.type==="year").value===t.y&&d>now){await L.schedule({notifications:[{id:799997,title:"أُنْس | التقويم الهجري",body:"لقد بدأ الشهر الهجري الذي حددته",schedule:{at:new Date(d)},channelId:notifChannel(),...NICON}]});break}}}catch(e){}}
function qibla(v){const [la,ln]=loc(),p1=la*R,p2=21.4225*R,dl=(39.8262-ln)*R;let b=Math.atan2(Math.sin(dl)*Math.cos(p2),Math.cos(p1)*Math.sin(p2)-Math.sin(p1)*Math.cos(p2)*Math.cos(dl))/R;b=(b+360)%360;
v.innerHTML='<div class="card" style="text-align:center"><div class="real-compass"><div class="compass-ring" id="compassRing"><span class="c-n">ش</span><span class="c-e">ق</span><span class="c-s">ج</span><span class="c-w">غ</span><div class="compass-ticks"></div><div class="compass-needle" id="ar2" style="transform:translate(-50%,-50%) rotate('+b+'deg)"><div class="needle-n"></div><div class="needle-s"></div><div class="needle-center"></div></div></div></div><h2>اتجاه القبلة '+Math.round(b)+'° من الشمال</h2><p class="t3">الموقع: '+city+'</p><button class="bt" id="cb">تفعيل البوصلة الحقيقية</button><p class="t3" id="cstatus">فعّل المستشعر ليتحرك القرص مع اتجاه الهاتف.</p></div>';
ch=e=>{let h=e.webkitCompassHeading!=null?e.webkitCompassHeading:(e.alpha!=null?360-e.alpha:null);if(h==null)return;const ring=$("#compassRing");if(ring)ring.style.transform="rotate("+(-h)+"deg)"};
$("#cb").onclick=async()=>{try{if(window.DeviceOrientationEvent&&DeviceOrientationEvent.requestPermission){const p=await DeviceOrientationEvent.requestPermission();if(p!=="granted")throw 0}addEventListener("deviceorientationabsolute",ch,true);addEventListener("deviceorientation",ch,true);$("#cstatus").textContent="تم تفعيل مستشعر الاتجاه"}catch(e){toast("تعذّر تشغيل البوصلة؛ تحقق من دعم الجهاز")}}}
const isDark=()=>{const t=document.documentElement.dataset.theme;return t?t=="dark":matchMedia("(prefers-color-scheme: dark)").matches};
function psec(){const [la,ln,tz]=loc(),t=ptimes(new Date(),la,ln,tz);return '<div class="card"><b>مواقيت الصلاة</b><p class="t3">تُحسب المواقيت تلقائيًا كل يوم حسب موقعك وتتغير مع تغيّر طول النهار طوال السنة. ويمكنك ضبط وقت كل صلاة يدويًا من حقل الساعة مع اختيار صباحًا أو مساءً، أو استخدام التعديل بالدقائق.</p><div class="row"><span>طريقة الحساب</span><select id="pm">'+MET.map((m,i)=>'<option value="'+i+'" '+(i==pm?"selected":"")+'>'+m[0]+'</option>').join("")+'</select></div>'+PN.map((n,i)=>'<div class="row"><span>'+n+' <span class="t3">'+fmt(t[i])+'</span></span><span class="prayer-adjust"><input type="time" aria-label="توقيت '+n+'" data-time="'+i+'" value="'+(pcustom[i]||"")+'"><button class="chip" data-a="'+i+'" data-d="-1">−</button><b>'+(adj[i]>0?"+":"")+ar(adj[i]||0)+' د</b><button class="chip" data-a="'+i+'" data-d="1">+</button></span></div>').join("")+'<p><button class="bt" id="pr0">إعادة الضبط التلقائي</button></p></div>'}
function settings(v){const rr=()=>{const y=v.scrollTop;settings(v);v.scrollTop=y};const sf=()=>{document.documentElement.style.setProperty("--qfs",fs+"px");store.s("fs",fs)};
 v.innerHTML='<div class="card"><div class="row"><span>إعدادات الإشعارات والتذكيرات</span><button class="chip" id="openNotif">فتح الإعدادات</button></div><div class="row"><span>الوضع الليلي</span><button class="chip '+(isDark()?"on":"")+'" id="s1">'+(isDark()?"مفعّل":"متوقف")+'</button></div><div class="row"><span>حجم خط القرآن</span><span><button class="chip" id="s2" aria-label="تصغير">−</button> <button class="chip" id="s3" aria-label="تكبير">+</button></span></div></div>'+psec()+'<div class="card"><b class="brand" style="font-size:22px">أُنْس <span class="sep">|</span> <span class="lat">UNSS</span></b><p class="t3">أنيس قلبك إلى الله</p><p class="t3">نص القرآن الكريم من مشروع <a href="https://tanzil.net" target="_blank" rel="noopener" style="color:var(--gold)">تنزيل (tanzil.net)</a>. التفسير: التفسير الميسر.</p></div>';
 const onf=$("#openNotif");if(onf)onf.onclick=()=>go("notif");$("#s1").onclick=()=>{const d=!isDark();document.documentElement.dataset.theme=d?"dark":"light";store.s("theme",d?"dark":"light");settings(v)};
 $("#s2").onclick=()=>{fs=Math.max(20,fs-2);sf()};$("#s3").onclick=()=>{fs=Math.min(40,fs+2);sf()};
 $("#pm").onchange=e=>{pm=+e.target.value;store.s("pm",pm);schedulePrayerNotifications();rr()};v.querySelectorAll("[data-time]").forEach(e=>e.onchange=()=>{pcustom[e.dataset.time]=e.value;store.s("pcustom",pcustom);schedulePrayerNotifications();rr()});
 v.querySelectorAll("[data-a]").forEach(b=>b.onclick=()=>{const i=+b.dataset.a;adj[i]=Math.max(-60,Math.min(60,(adj[i]||0)+ +b.dataset.d));store.s("adj",adj);schedulePrayerNotifications();rr()});$("#pr0").onclick=()=>{pm=0;adj=[0,0,0,0,0];pcustom={};store.s("pcustom",pcustom);store.s("pm",0);store.s("adj",adj);schedulePrayerNotifications();rr()}}
const SC={home,khatma,quran,reader,tafsir,hadith,story,tasbih,pray,qibla,calendar,favs,notif,settings,dua:v=>dhikr(v,"d"),adhkar:v=>dhikr(v,"a")};
const pageStack=[];
function go(n,p){if(n===cur&&p===param)return;pageStack.push({cur,param});cur=n;param=p;try{history.pushState({anis:true,depth:pageStack.length},"","#"+n)}catch(e){}render()}
function restoreStep(){if(pageStack.length){const prev=pageStack.pop();cur=prev.cur;param=prev.param;render()}else if(cur!=="home"){cur="home";param=null;render()}}
function backStep(){if(cur==="reader"&&imm){imm=false;applyImm();return}if(pageStack.length){history.back()}else if(cur!=="home"){cur="home";param=null;render()}}
addEventListener("popstate",()=>restoreStep());
function nav(){$("#nav").innerHTML=NAVS.map(n=>'<button role="tab" aria-selected="'+(n[0]==cur)+'" data-t="'+n[0]+'">'+svg(NI[n[0]])+n[1]+'</button>').join("");$("#nav").querySelectorAll("button").forEach(b=>b.onclick=()=>go(b.dataset.t))}
function applyImm(){const on=cur=="reader"&&imm;document.body.classList.toggle("rd",cur=="reader");document.body.classList.toggle("immersive",on);$("#xb").hidden=true;try{if(on){if(!document.fullscreenElement&&document.documentElement.requestFullscreen)document.documentElement.requestFullscreen().catch(()=>{})}else if(document.fullscreenElement)document.exitFullscreen()}catch(e){}}
function render(){document.body.dataset.s=cur;clearInterval(tick);$("#v").onscroll=null;if(cur!="reader")imm=false;applyImm();$("#rpl").hidden=$("#rpr").hidden=cur!="reader";if(ch){removeEventListener("deviceorientation",ch,true);removeEventListener("deviceorientationabsolute",ch,true);ch=null}
 $("#hd").innerHTML=cur=="home"?LOGO+'<h1 class="brand">أُنْس <span class="sep">|</span> <span class="lat">UNSS</span></h1>':'<button id="bk" aria-label="رجوع"><svg viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></svg></button><h1>'+TITLES[cur]+'</h1>';
 if(cur!="home")$("#bk").onclick=()=>backStep();
 const v=$("#v");v.scrollTop=0;SC[cur](v);nav()}
const sv=store.g("theme",null);if(sv)document.documentElement.dataset.theme=sv;
document.documentElement.style.setProperty("--qfs",fs+"px");
new MutationObserver(()=>{if(cur!="favs")favScan($("#v"))}).observe($("#v"),{childList:true});
$("#xb").onclick=()=>{imm=false;applyImm()};
addEventListener("fullscreenchange",()=>{if(!document.fullscreenElement&&imm&&cur=="reader"){imm=false;applyImm()}});
render();
(async function firstLaunchPermissions(){
 if(store.g("firstLaunchPermissions",false))return;
 store.s("firstLaunchPermissions",true);
 if(!geo&&navigator.geolocation){
  navigator.geolocation.getCurrentPosition(p=>{geo={lat:p.coords.latitude,lng:p.coords.longitude};store.s("geo",geo);city="موقعي";store.s("city",city);render();schedulePrayerNotifications()},()=>toast("يمكنك اختيار مدينتك يدويًا أو السماح بالوصول للموقع من إعدادات الجهاز"),{enableHighAccuracy:true,timeout:15000,maximumAge:3600000});
 }
 const L=LocalNotifs();
 if(L){try{const ok=await requestLocalPermission();if(ok){nf.en=true;nf.pr=true;nf.ad=true;nf.on=true;nf.last=Date.now();store.s("nf",nf);await schedulePrayerNotifications()}}catch(e){}}
})();
scheduleHijriAlert();
